package main;

import views.LoginView;

public class App {

    public static void main(String[] args) {
        LoginView login = new LoginView();
        login.setVisible(true);
    }
    
}
